from analytics import get_average_mood_last_7_days, detect_trend_for_student
averages = get_average_mood_last_7_days()
trend = detect_trend_for_student("alexj")  # example student_id

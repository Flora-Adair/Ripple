from flask import Flask, render_template
from flask_login import LoginManager
from dotenv import load_dotenv
import os
from datetime import datetime

# Load environment variables from .env
load_dotenv()

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "your_default_dev_secret")

# -------------------------------
# Flask-Login setup
# -------------------------------
login_manager = LoginManager()
login_manager.login_view = "auth.login"
login_manager.init_app(app)

# -------------------------------
# Import Blueprints and User model
# -------------------------------
from auth import auth, google_bp, users, User  # users and User must be imported here
from mood import mood

# Shared user_loader for Flask-Login
@login_manager.user_loader
def load_user(user_id):
    return users.get(int(user_id))

# -------------------------------
# Register Blueprints
# -------------------------------
app.register_blueprint(google_bp, url_prefix="/auth/google")  # OAuth-related routes
app.register_blueprint(auth, url_prefix="/auth")              # login, register, dashboard
app.register_blueprint(mood, url_prefix="/mood")              # mood logging routes

# -------------------------------
# Global context
# -------------------------------
@app.context_processor
def inject_now():
    return {'now': datetime.now()}

# -------------------------------
# Basic routes
# -------------------------------
@app.route("/")
def home():
    return render_template("home.html")

@app.route("/about")
def about():
    return render_template("about.html")

# -------------------------------
# Run the app
# -------------------------------
if __name__ == "__main__":
    app.run(debug=True)
